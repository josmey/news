package com.example.news.view

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.news.R
import com.example.news.adapter.NewsAdapter
import com.example.news.databinding.ActivityMainBinding
import com.example.news.viewmodel.MainActivityViewModel

class MainActivity :AppCompatActivity() {

    lateinit var context: Context

    lateinit var mainActivityViewModel: MainActivityViewModel
    private lateinit var binding: ActivityMainBinding
    lateinit var viewModel: MainActivityViewModel
    //private val retrofitService = ApiInterface.getInstance()
    var adapter = NewsAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        Log.e("Tag","here")
        context = this@MainActivity

        viewModel = ViewModelProvider(this).get(MainActivityViewModel::class.java)
        viewModel.getUser()!!.observe(this, Observer { serviceSetlterGetter ->
            //
            val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)


            binding.myNewsList.setLayoutManager(layoutManager)
            viewModel.servicesLiveData?.observe(this, Observer {
                Log.e("TAG", "onCreate: ${it.article.size}")

                adapter.setNewsList(it.article,this)
                binding.myNewsList.adapter = adapter
            })

           // viewModel.getUser()


        })
    }
}