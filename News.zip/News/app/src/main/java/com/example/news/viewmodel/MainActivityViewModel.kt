package com.example.news.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.news.model.NewsList
import com.example.news.repository.MainActivityRepository


class MainActivityViewModel : ViewModel() {

    var servicesLiveData: MutableLiveData<NewsList>? = null

    fun getUser() : LiveData<NewsList>? {
        servicesLiveData = MainActivityRepository.getServicesApiCall()
        return servicesLiveData
    }

}