package com.example.news.repository

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.news.model.NewsList
import com.example.news.retrofit.ApiInterface
import com.example.news.retrofit.RetrofitClient

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object MainActivityRepository {

    val serviceSetterGetter = MutableLiveData<NewsList>()
    var retrofitService: ApiInterface? = null
    fun getServicesApiCall(): MutableLiveData<NewsList> {

        val call= RetrofitClient.apiInterface.getServices("keyword","0a5a358d5ac146d79c2a020a80ff0e67")

        call?.enqueue(object: Callback<NewsList> {
            override fun onFailure(call: Call<NewsList>, t: Throwable) {
                // TODO("Not yet implemented")
                Log.v("DEBUG : ", t.message.toString())
            }

            override fun onResponse(
                call: Call<NewsList>,
                response: Response<NewsList>
            ) {
                // TODO("Not yet implemented")
                Log.v("DEBUG : ", response.body().toString())

                val data = response.body()

                val msg = data!!.status
                val total=data!!.totalResults
                val result=data!!.article

                serviceSetterGetter.value = NewsList(msg,total,result)
            }
        })

        return serviceSetterGetter
    }
}