package com.example.news.adapter


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.news.databinding.NewsModelViewBinding
import com.example.news.model.Articles
import com.example.news.view.DetailActivity

class NewsAdapter :RecyclerView.Adapter<MainViewHolder>() {
    var news = mutableListOf<Articles>()
    lateinit var mcontext:Context
    fun setNewsList(news: List<Articles>, mcontext:Context) {
        this.news = news.toMutableList()
        this.mcontext=mcontext

    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = NewsModelViewBinding.inflate(inflater, parent, false)
        return MainViewHolder(binding)
    }
    override fun onBindViewHolder(holder: MainViewHolder, position: Int) {
        val news = news[position]
        holder.binding.name.text = news.source?.name
        holder.binding.discription.text=news.content
        holder.binding.date.text="Updated :"+news.publishedAt
        Glide.with(holder.itemView.context).load(news.urlToImage).into(holder.binding.imageview)
        val bundle = Bundle()
        bundle.putString("name", news.source?.name)
        bundle.putString("description", news.content)
        bundle.putString("updated",news.publishedAt)
        bundle.putString("image",news.urlToImage)
        holder.itemView.setOnClickListener {
            val intent = Intent(mcontext, DetailActivity::class.java)
            intent.putExtras(bundle)

            mcontext.startActivity(intent)
        }

    }
    override fun getItemCount(): Int {
        Log.e("news","news ${news.size}")
        return news.size
    }
}
class MainViewHolder(val binding: NewsModelViewBinding) : RecyclerView.ViewHolder(binding.root) {
}