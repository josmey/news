package com.example.news.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.news.R
import com.example.news.databinding.DiscriptionActivityBinding


class DetailActivity : AppCompatActivity() {

    private lateinit var binding: DiscriptionActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.discription_activity)
        binding = DiscriptionActivityBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        val bundle = intent.extras

        var name:String? = null
        var disc:String? = null
        var date:String? = null
        var image:String? = null

        name = bundle!!.getString("name", "Default")
        disc = bundle!!.getString("description", "Default")
        date = bundle!!.getString("updated", "Default")
        image = bundle!!.getString("image", "Default")
        binding.name.text =name
        binding.discription.text=disc
        binding.date.text="Updated :"+date
        Glide.with(this).load(image).into(binding.imageview)
    }
}
