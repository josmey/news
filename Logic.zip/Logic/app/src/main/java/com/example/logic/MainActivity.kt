package com.example.logic

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import androidx.appcompat.app.AppCompatActivity
import com.example.logic.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
      var value=  binding.editText.text.toString()
        binding.button.setOnClickListener {
            isPalindromeString(value)
        }



    }
    @SuppressLint("SuspiciousIndentation")
    fun reverse(){
        val nums = listOf(2, 4, 9, 3, 7)
        val length = nums.size
        val toIndex =(length+1) /2
        val fromIndex = 0
        val result = nums.subList(fromIndex, toIndex)

            println("middle element  $result")


    }

    fun isPalindromeString(inputStr: String): Boolean {
        val sb = StringBuilder(inputStr)

        //reverse the string
        val reverseStr = sb.reverse().toString()

        //compare reversed string with input string
        return inputStr.equals(reverseStr, ignoreCase = true)
    }

}


